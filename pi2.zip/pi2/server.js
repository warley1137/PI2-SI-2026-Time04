import express from 'express'
import cors from 'cors'
import mysql from 'mysql2/promise'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const app = express()
const port = 3001
const DB_CONFIG = {
  host: '127.0.0.1',
  port: 3306,
  user: 'root',
  password: '',
  database: 'pronto_socorro',
  waitForConnections: true,
  connectionLimit: 10,
}

app.use(cors())
app.use(express.json())

const db = mysql.createPool(DB_CONFIG)

const statusMap = {
  AGUARDANDO_TRIAGEM: 'Aguardando triagem',
  AGUARDANDO_MEDICO: 'Aguardando atendimento',
  EM_ATENDIMENTO: 'Em atendimento',
  FINALIZADO: 'Finalizado',
  CANCELADO: 'Cancelado',
}

async function runScriptFile(filePath) {
  const sql = await fs.readFile(filePath, 'utf8')
  const statements = sql
    .split(';')
    .map((statement) => statement.trim())
    .filter(Boolean)

  const connection = await mysql.createConnection({
    host: DB_CONFIG.host,
    port: DB_CONFIG.port,
    user: DB_CONFIG.user,
    password: DB_CONFIG.password,
    database: DB_CONFIG.database,
  })

  for (const statement of statements) {
    await connection.execute(statement)
  }

  await connection.end()
}

async function initializeDatabase() {
  const adminConnection = await mysql.createConnection({
    host: DB_CONFIG.host,
    port: DB_CONFIG.port,
    user: DB_CONFIG.user,
    password: DB_CONFIG.password,
  })

  await adminConnection.execute('CREATE DATABASE IF NOT EXISTS pronto_socorro')
  await adminConnection.end()

  const [result] = await db.execute('SELECT 1')
  if (!result) {
    throw new Error('Banco MySQL não disponível.')
  }

  const schemaSqlPath = path.join(__dirname, 'banco-de-dados', '01_criacao_tabelas.sql')
  const seedSqlPath = path.join(__dirname, 'banco-de-dados', '02_dados_iniciais.sql')

  try {
    await runScriptFile(schemaSqlPath)
  } catch (error) {
    console.warn('Schema já existe ou não foi necessário recriar:', error.message)
  }

  const [rows] = await db.execute('SELECT COUNT(*) AS total FROM paciente')
  const totalPacientes = rows[0]?.total ?? 0

  if (Number(totalPacientes) === 0) {
    await runScriptFile(seedSqlPath)
  }
}

function formatPatient(row) {
  if (!row) {
    return null
  }

  return {
    id: `P${String(row.id_paciente).padStart(3, '0')}`,
    name: row.nome,
    address: row.logradouro || '',
    rg: row.rg || '',
    cpf: row.cpf || '',
    father: row.nome_pai || '',
    mother: row.nome_mae || '',
    birthDate: row.data_nascimento || '',
  }
}

function formatAttendance(row, triageRow) {
  if (!row) {
    return null
  }

  const patientId = `P${String(row.id_paciente).padStart(3, '0')}`
  const attendanceId = row.numero_atendimento || `AT${String(row.id_atendimento).padStart(4, '0')}`

  return {
    id: attendanceId,
    patientId,
    status: statusMap[row.status] || row.status,
    arrival: row.dt_chegada
      ? new Date(row.dt_chegada).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      : '',
    priority: triageRow ? triageRow.classificacao : null,
    triage: triageRow
      ? {
          bloodPressure: `${triageRow.pressao_sistolica}/${triageRow.pressao_diastolica}`,
          temperature: String(triageRow.temperatura),
          heartRate: String(triageRow.frequencia_cardiaca),
          complaint: triageRow.outras_queixas || '',
          risk: triageRow.classificacao,
        }
      : null,
  }
}

app.get('/api/pacientes', async (_request, response) => {
  const [rows] = await db.execute('SELECT * FROM paciente ORDER BY id_paciente DESC')
  response.json(rows.map(formatPatient))
})

app.post('/api/pacientes', async (request, response) => {
  const { name, address, rg, cpf, father, mother, birthDate } = request.body

  const [result] = await db.execute(
    `INSERT INTO paciente (nome, logradouro, rg, cpf, nome_pai, nome_mae, data_nascimento, dt_cadastro)
     VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
    [name, address, rg, cpf, father || '', mother || '', birthDate],
  )

  const [rows] = await db.execute('SELECT * FROM paciente WHERE id_paciente = ?', [result.insertId])
  response.status(201).json(formatPatient(rows[0]))
})

app.get('/api/atendimentos', async (_request, response) => {
  const [rows] = await db.execute('SELECT * FROM atendimento ORDER BY id_atendimento DESC')
  const [triages] = await db.execute(
    `SELECT id_atendimento, pressao_sistolica, pressao_diastolica, temperatura, frequencia_cardiaca, classificacao, queixas AS outras_queixas
     FROM triagem`,
  )

  const triageMap = Object.fromEntries(triages.map((triage) => [triage.id_atendimento, triage]))
  const data = rows.map((row) => formatAttendance(row, triageMap[row.id_atendimento]))

  response.json(data)
})

app.post('/api/atendimentos', async (request, response) => {
  const { patientId, complaint } = request.body

  const patientInternalId = Number(String(patientId).replace(/^P0*/, ''))

  const [patientRows] = await db.execute('SELECT * FROM paciente WHERE id_paciente = ?', [patientInternalId])
  if (!patientRows.length) {
    response.status(400).json({ error: 'Paciente não encontrado.' })
    return
  }

  const [nextNumberRows] = await db.execute('SELECT COALESCE(MAX(id_atendimento), 0) + 1 AS nextId FROM atendimento')
  const generatedNumber = `AT${String(nextNumberRows[0].nextId).padStart(4, '0')}`

  const [result] = await db.execute(
    `INSERT INTO atendimento (numero_atendimento, id_paciente, dt_chegada, status, observacao)
     VALUES (?, ?, NOW(), 'AGUARDANDO_TRIAGEM', ?)`,
    [generatedNumber, patientInternalId, complaint || ''],
  )

  const [createdRows] = await db.execute('SELECT * FROM atendimento WHERE id_atendimento = ?', [result.insertId])
  response.status(201).json(formatAttendance(createdRows[0], null))
})

app.put('/api/atendimentos/:id/triagem', async (request, response) => {
  const attendanceIdParam = request.params.id
  const { bloodPressure, temperature, heartRate, complaint, priority } = request.body

  const [existingRows] = await db.execute(
    'SELECT * FROM atendimento WHERE numero_atendimento = ? OR id_atendimento = ?',
    [attendanceIdParam, Number(attendanceIdParam)],
  )

  if (!existingRows.length) {
    response.status(404).json({ error: 'Atendimento não encontrado.' })
    return
  }

  const validPriority = ['Vermelho', 'Laranja', 'Amarelo', 'Verde', 'Azul']
  if (!validPriority.includes(priority)) {
    response.status(400).json({ error: 'Classificação inválida.' })
    return
  }

  const [sistolica, diastolica] = String(bloodPressure || '120/80')
    .split('/')
    .map((value) => Number((value || '').trim()))

  const existingAttendance = existingRows[0]
  const [triageRows] = await db.execute('SELECT * FROM triagem WHERE id_atendimento = ?', [existingAttendance.id_atendimento])

  if (triageRows.length) {
    await db.execute(
      `UPDATE triagem
       SET pressao_sistolica = ?, pressao_diastolica = ?, temperatura = ?, frequencia_cardiaca = ?, classificacao = ?, queixas = ?
       WHERE id_atendimento = ?`,
      [
        sistolica || 120,
        diastolica || 80,
        Number(temperature || 36.8),
        Number(heartRate || 80),
        priority,
        complaint || '',
        existingAttendance.id_atendimento,
      ],
    )
  } else {
    await db.execute(
      `INSERT INTO triagem (id_atendimento, pressao_sistolica, pressao_diastolica, temperatura, frequencia_cardiaca, classificacao, queixas, dt_triagem)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        existingAttendance.id_atendimento,
        sistolica || 120,
        diastolica || 80,
        Number(temperature || 36.8),
        Number(heartRate || 80),
        priority,
        complaint || '',
      ],
    )
  }

  await db.execute(`UPDATE atendimento SET status = 'AGUARDANDO_MEDICO' WHERE id_atendimento = ?`, [existingAttendance.id_atendimento])

  response.json({ ok: true })
})

app.put('/api/atendimentos/:id/finalizar', async (request, response) => {
  const attendanceIdParam = request.params.id
  const [rows] = await db.execute('SELECT * FROM atendimento WHERE numero_atendimento = ? OR id_atendimento = ?', [attendanceIdParam, Number(attendanceIdParam)])

  if (!rows.length) {
    response.status(404).json({ error: 'Atendimento não encontrado.' })
    return
  }

  await db.execute(`UPDATE atendimento SET status = 'FINALIZADO' WHERE id_atendimento = ?`, [rows[0].id_atendimento])
  response.json({ ok: true })
})

app.put('/api/atendimentos/:id/cancelar', async (request, response) => {
  const attendanceIdParam = request.params.id
  const [rows] = await db.execute('SELECT * FROM atendimento WHERE numero_atendimento = ? OR id_atendimento = ?', [attendanceIdParam, Number(attendanceIdParam)])

  if (!rows.length) {
    response.status(404).json({ error: 'Atendimento não encontrado.' })
    return
  }

  await db.execute(`UPDATE atendimento SET status = 'CANCELADO' WHERE id_atendimento = ?`, [rows[0].id_atendimento])
  response.json({ ok: true })
})

await initializeDatabase()

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`)
})
