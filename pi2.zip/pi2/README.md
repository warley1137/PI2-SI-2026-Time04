# Sistema de Atendimento de Pronto Socorro

Projeto acadêmico desenvolvido para o PI2, com foco em recepção, triagem e atendimento médico em um ambiente de pronto atendimento.

## Funcionalidades

- Cadastro de pacientes
- Abertura de atendimento na recepção
- Registro de sinais vitais e classificação de risco
- Painel médico com fila prioritária por Manchester
- Confirmação de alta e cancelamento de atendimento
- Banco de dados local em SQLite

## Tecnologias

- React
- Vite
- Node.js + Express
- SQLite

## Como executar

1. Instale as dependências:
   ```bash
   npm install
   ```
2. Inicie o projeto:
   ```bash
   npm run dev
   ```
3. Acesse o frontend em:
   ```text
   http://localhost:5173
   ```
4. A API fica em:
   ```text
   http://localhost:3001
   ```

## Estrutura do projeto

- src/: frontend React
- banco-de-dados/: scripts SQL do banco
- server.js: backend e conexão com SQLite

## Observação

Este projeto foi pensado para ser uma solução simples e funcional, adequada para apresentação em disciplina de nível inicial/intermediário de desenvolvimento.
