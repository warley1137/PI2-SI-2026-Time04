import './index.css'
import './App.css'

const priorityOrder = {
  Vermelho: 1,
  Laranja: 2,
  Amarelo: 3,
  Verde: 4,
  Azul: 5,
}

const priorityClasses = {
  Vermelho: 'priority-red',
  Laranja: 'priority-orange',
  Amarelo: 'priority-yellow',
  Verde: 'priority-green',
  Azul: 'priority-blue',
}

const actionLabel = {
  recepcao: 'Recepção',
  enfermagem: 'Enfermagem',
  medico: 'Médico',
}

const defaultPatientForm = {
  name: '',
  address: '',
  rg: '',
  cpf: '',
  father: '',
  mother: '',
  birthDate: '',
}

const state = {
  activeRole: 'recepcao',
  patients: [],
  attendances: [],
  selectedAttendance: '',
  patientForm: { ...defaultPatientForm },
  attendanceForm: { patientId: '', complaint: 'Dor abdominal' },
  triageForm: {
    attendanceId: '',
    bloodPressure: '120/80',
    temperature: '36.7',
    heartRate: '80',
    complaint: 'Dor no peito',
    priority: 'Laranja',
  },
  medicalNote: 'Paciente em observação e com melhora da dor.',
  medicationForm: {
    name: 'Dipirona',
    dosage: '1 g',
    via: 'VO',
  },
}

const roleSwitcher = document.querySelector('#roleSwitcher')
const activeUserLabel = document.querySelector('#activeUserLabel')
const panels = [...document.querySelectorAll('.panel')]
const patientFormElement = document.querySelector('#patientForm')
const attendanceFormElement = document.querySelector('#attendanceForm')
const triageFormElement = document.querySelector('#triageForm')
const attendancePatientSelect = document.querySelector('#attendancePatient')
const triageAttendanceSelect = document.querySelector('#triageAttendance')
const queueList = document.querySelector('#queueList')
const selectedPatientName = document.querySelector('#selectedPatientName')
const selectedPatientMeta = document.querySelector('#selectedPatientMeta')
const finishAttendanceButton = document.querySelector('#finishAttendance')
const cancelAttendanceButton = document.querySelector('#cancelAttendance')
let refreshTimer = null

function setActiveRole(role) {
  state.activeRole = role
  activeUserLabel.textContent = actionLabel[role]

  panels.forEach((panel) => {
    const isActive = panel.dataset.panel === role
    panel.classList.toggle('active-panel', isActive)
  })

  roleSwitcher.querySelectorAll('.role-button').forEach((button) => {
    button.classList.toggle('active', button.dataset.role === role)
  })
}

function renderRoleButtons() {
  roleSwitcher.innerHTML = Object.entries(actionLabel)
    .map(
      ([key, label]) => `
        <button
          type="button"
          class="role-button ${state.activeRole === key ? 'active' : ''}"
          data-role="${key}"
        >
          ${label}
        </button>
      `,
    )
    .join('')

  roleSwitcher.querySelectorAll('.role-button').forEach((button) => {
    button.addEventListener('click', () => setActiveRole(button.dataset.role))
  })
}

function buildSummary() {
  const openAttendments = state.attendances.filter(
    (item) => item.status !== 'Finalizado' && item.status !== 'Cancelado',
  ).length
  const highPriority = state.attendances.filter(
    (item) => item.priority === 'Vermelho' || item.priority === 'Laranja',
  ).length
  const completed = state.attendances.filter((item) => item.status === 'Finalizado').length
  const waitingTriage = state.attendances.filter((item) => item.status === 'Aguardando triagem').length

  document.querySelector('#openAttendments').textContent = String(openAttendments)
  document.querySelector('#waitingTriage').textContent = String(waitingTriage)
  document.querySelector('#highPriority').textContent = String(highPriority)
  document.querySelector('#completed').textContent = String(completed)
}

function getPatientsById() {
  return Object.fromEntries(state.patients.map((patient) => [patient.id, patient]))
}

function getQueue() {
  return [...state.attendances]
    .filter((item) => item.status !== 'Cancelado' && item.status !== 'Finalizado')
    .sort((a, b) => {
      const priorityA = a.priority ? priorityOrder[a.priority] : 999
      const priorityB = b.priority ? priorityOrder[b.priority] : 999

      if (priorityA !== priorityB) {
        return priorityA - priorityB
      }

      return (a.arrival || '').localeCompare(b.arrival || '')
    })
}

function renderForms() {
  const patientsById = getPatientsById()

  attendancePatientSelect.innerHTML = state.patients
    .map((patient) => `<option value="${patient.id}">${patient.id} - ${patient.name}</option>`)
    .join('')

  if (state.patients.length && !state.attendanceForm.patientId) {
    state.attendanceForm.patientId = state.patients[0].id
  }

  if (state.attendanceForm.patientId) {
    attendancePatientSelect.value = state.attendanceForm.patientId
  }

  triageAttendanceSelect.innerHTML = state.attendances
    .map(
      (item) =>
        `<option value="${item.id}">${item.id} - ${patientsById[item.patientId]?.name ?? 'Paciente'}</option>`,
    )
    .join('')

  if (state.attendances.length && !state.triageForm.attendanceId) {
    state.triageForm.attendanceId = state.attendances[0].id
  }

  if (state.triageForm.attendanceId) {
    triageAttendanceSelect.value = state.triageForm.attendanceId
  }
}

function renderQueue() {
  const patientsById = getPatientsById()
  const queue = getQueue()

  queueList.innerHTML = queue
    .map((item) => {
      const patient = patientsById[item.patientId]
      const isSelected = item.id === state.selectedAttendance
      return `
        <button type="button" class="queue-item ${isSelected ? 'selected' : ''}" data-attendance-id="${item.id}">
          <div class="queue-main">
            <strong>${item.id}</strong>
            <span>${patient?.name ?? 'Paciente'}</span>
          </div>
          <div class="queue-meta">
            <small>${patient?.birthDate ?? 'Data não informada'}</small>
            <span class="priority-badge ${item.priority ? priorityClasses[item.priority] : 'neutral'}">
              ${item.priority ?? 'Sem triagem'}
            </span>
          </div>
        </button>
      `
    })
    .join('')

  queueList.querySelectorAll('.queue-item').forEach((button) => {
    button.addEventListener('click', () => {
      state.selectedAttendance = button.dataset.attendanceId
      renderQueue()
      renderSelectedPatient()
    })
  })
}

function renderSelectedPatient() {
  const patientsById = getPatientsById()
  const selectedAttendance = state.attendances.find((item) => item.id === state.selectedAttendance)
  const selectedPatient = patientsById[selectedAttendance?.patientId] ?? state.patients[0]

  selectedPatientName.textContent = selectedPatient?.name ?? 'Selecionar paciente'
  selectedPatientMeta.textContent = selectedAttendance
    ? `${selectedAttendance.id} • ${selectedPatient?.birthDate ?? 'Data de nascimento'} • ${selectedAttendance.priority ?? 'Sem priorização'}`
    : '-'
}

function render() {
  buildSummary()
  renderForms()
  renderQueue()
  renderSelectedPatient()
  document.querySelector('#medicalNote').value = state.medicalNote
  document.querySelector('#medName').value = state.medicationForm.name
  document.querySelector('#medDosage').value = state.medicationForm.dosage
  document.querySelector('#medVia').value = state.medicationForm.via
}

async function loadData() {
  try {
    const [patientsResponse, attendancesResponse] = await Promise.all([
      fetch('/api/pacientes'),
      fetch('/api/atendimentos'),
    ])

    const patients = await patientsResponse.json()
    const attendances = await attendancesResponse.json()

    state.patients = patients
    state.attendances = attendances

    if (!state.selectedAttendance && attendances.length > 0) {
      state.selectedAttendance = attendances[0].id
    }

    if (patients.length > 0 && !state.attendanceForm.patientId) {
      state.attendanceForm.patientId = patients[0].id
    }

    if (attendances.length > 0 && !state.triageForm.attendanceId) {
      state.triageForm.attendanceId = attendances[0].id
    }
  } catch (error) {
    console.error('Erro ao carregar dados:', error)
  }

  render()
}

patientFormElement.addEventListener('submit', async (event) => {
  event.preventDefault()

  const formData = Object.fromEntries(new FormData(patientFormElement).entries())
  const response = await fetch('/api/pacientes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(formData),
  })

  if (response.ok) {
    patientFormElement.reset()
    await loadData()
  }
})

attendanceFormElement.addEventListener('submit', async (event) => {
  event.preventDefault()

  const formData = Object.fromEntries(new FormData(attendanceFormElement).entries())
  const response = await fetch('/api/atendimentos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      patientId: formData.patientId,
      complaint: formData.complaint,
    }),
  })

  if (response.ok) {
    const created = await response.json()
    state.selectedAttendance = created.id
    state.triageForm.attendanceId = created.id
    await loadData()
  }
})

triageFormElement.addEventListener('submit', async (event) => {
  event.preventDefault()

  const formData = Object.fromEntries(new FormData(triageFormElement).entries())

  await fetch(`/api/atendimentos/${formData.attendanceId}/triagem`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      bloodPressure: formData.bloodPressure,
      temperature: formData.temperature,
      heartRate: formData.heartRate,
      complaint: formData.complaint,
      priority: formData.priority,
    }),
  })

  state.activeRole = 'medico'
  setActiveRole(state.activeRole)
  await loadData()
})

finishAttendanceButton.addEventListener('click', async () => {
  if (!state.selectedAttendance) return

  await fetch(`/api/atendimentos/${state.selectedAttendance}/finalizar`, { method: 'PUT' })
  await loadData()
})

cancelAttendanceButton.addEventListener('click', async () => {
  if (!state.selectedAttendance) return

  await fetch(`/api/atendimentos/${state.selectedAttendance}/cancelar`, { method: 'PUT' })
  await loadData()
})

document.querySelector('#medicalNote').addEventListener('input', (event) => {
  state.medicalNote = event.target.value
})

document.querySelector('#medName').addEventListener('input', (event) => {
  state.medicationForm.name = event.target.value
})

document.querySelector('#medDosage').addEventListener('input', (event) => {
  state.medicationForm.dosage = event.target.value
})

document.querySelector('#medVia').addEventListener('change', (event) => {
  state.medicationForm.via = event.target.value
})

function startAutoRefresh() {
  if (refreshTimer) {
    clearInterval(refreshTimer)
  }

  refreshTimer = setInterval(() => {
    loadData()
  }, 4000)
}

renderRoleButtons()
setActiveRole('recepcao')
loadData()
startAutoRefresh()
