# Banco de Dados

Este diretório reúne os scripts de criação e carga inicial do banco do sistema de pronto atendimento.

## Execução

1. `01_criacao_tabelas.sql`: cria as tabelas do sistema.
2. `02_dados_iniciais.sql`: carrega dados iniciais e exemplos.

## Estrutura principal

- paciente
- atendimento
- triagem
- classificacao_risco
- prescricao
- medicamento

## Status do atendimento

- AGUARDANDO_TRIAGEM
- AGUARDANDO_MEDICO
- EM_ATENDIMENTO
- FINALIZADO
- CANCELADO
