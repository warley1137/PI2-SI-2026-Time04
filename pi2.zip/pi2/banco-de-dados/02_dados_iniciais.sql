INSERT INTO profissional (nome, cpf, funcao, registro_conselho, login, senha_hash) VALUES
  ('Ana Silva', '52601815906', 'RECEPCIONISTA', NULL, 'ana.recepcao', 'PENDENTE'),
  ('Bruno Souza', '08301661305', 'ENFERMEIRO', 'COREN-SP 123456', 'bruno.enf', 'PENDENTE'),
  ('Dra. Carla Lima', '18609139034', 'MEDICO', 'CRM-SP 654321', 'carla.med', 'PENDENTE');

INSERT INTO paciente (nome, cpf, rg, data_nascimento, sexo, nome_mae, nome_pai, telefone,
  cep, logradouro, numero, complemento, bairro, cidade, uf) VALUES
  ('João Pereira Santos', '99603082430', '12.345.678-9', '1985-03-12', 'M', 'Maria Pereira', 'José Santos', '19991110001', '13087000', 'Rua das Flores', '100', NULL, 'Centro', 'Campinas', 'SP'),
  ('Mariana Costa Oliveira', '62819482112', '23.456.789-0', '1999-07-25', 'F', 'Lúcia Costa', 'Paulo Oliveira', '19991110002', '13083000', 'Av. Brasil', '2500', NULL, 'Jardim Guanabara', 'Campinas', 'SP'),
  ('Pedro Henrique Alves', '99351819019', '34.567.890-1', '1952-11-03', 'M', 'Rosa Alves', 'Antônio Alves', '19991110003', '13010000', 'Rua Barão de Jaguara', '45', NULL, 'Centro', 'Campinas', 'SP'),
  ('Beatriz Ramos Ferreira', '93786579741', '45.678.901-2', '2015-02-18', 'F', 'Juliana Ramos', 'Carlos Ferreira', '19991110004', '13087500', 'Rua Guatemala', '310', NULL, 'Jardim Nova Europa', 'Campinas', 'SP'),
  ('Ricardo Gomes Barbosa', '54323194897', '56.789.012-3', '1978-09-30', 'M', 'Sandra Gomes', 'Roberto Barbosa', '19991110005', '13084000', 'Rua Sacramento', '77', NULL, 'Cambuí', 'Campinas', 'SP'),
  ('Fernanda Lopes Dias', '75749118606', '67.890.123-4', '1990-12-05', 'F', 'Clara Lopes', 'Marcos Dias', '19991110006', '13086000', 'Rua Coronel Quirino', '1200', NULL, 'Cambuí', 'Campinas', 'SP');

INSERT INTO atendimento (numero_atendimento, id_paciente, dt_chegada, status, dt_confirmacao, dt_cancelamento, motivo_cancelamento) VALUES
  ('AT0001', 1, NOW() - INTERVAL 180 MINUTE, 'FINALIZADO', NOW() - INTERVAL 80 MINUTE, NULL, NULL),
  ('AT0002', 2, NOW() - INTERVAL 50 MINUTE, 'AGUARDANDO_MEDICO', NULL, NULL, NULL),
  ('AT0003', 3, NOW() - INTERVAL 20 MINUTE, 'AGUARDANDO_MEDICO', NULL, NULL, NULL),
  ('AT0004', 4, NOW() - INTERVAL 90 MINUTE, 'AGUARDANDO_MEDICO', NULL, NULL, NULL),
  ('AT0005', 5, NOW() - INTERVAL 5 MINUTE, 'AGUARDANDO_TRIAGEM', NULL, NULL, NULL),
  ('AT0006', 6, NOW() - INTERVAL 30 MINUTE, 'CANCELADO', NULL, NOW() - INTERVAL 25 MINUTE, 'Paciente desistiu antes da triagem');

INSERT INTO triagem (id_atendimento, pressao_sistolica, pressao_diastolica, temperatura, frequencia_cardiaca, queixas, classificacao, dt_triagem) VALUES
  (1, 130, 85, 38.2, 95, 'Febre, dor muscular, dor de cabeça', 'Verde', NOW() - INTERVAL 170 MINUTE),
  (2, 110, 70, 36.8, 88, 'Náusea, vômito (3 vezes desde a manhã), dor abdominal', 'Amarelo', NOW() - INTERVAL 40 MINUTE),
  (3, 170, 100, 36.5, 112, 'Dor no peito irradiando para o braço, suor, falta de ar', 'Laranja', NOW() - INTERVAL 15 MINUTE),
  (4, 100, 65, 37.4, 100, 'Tosse, febre', 'Verde', NOW() - INTERVAL 80 MINUTE);

INSERT INTO prontuario (id_atendimento, id_profissional, etapa, dt_inicio, dt_fim, anotacao) VALUES
  (1, 1, 'RECEPCAO', NOW() - INTERVAL 180 MINUTE, NOW() - INTERVAL 177 MINUTE, NULL),
  (2, 1, 'RECEPCAO', NOW() - INTERVAL 50 MINUTE, NOW() - INTERVAL 47 MINUTE, NULL),
  (3, 1, 'RECEPCAO', NOW() - INTERVAL 20 MINUTE, NOW() - INTERVAL 17 MINUTE, NULL),
  (4, 1, 'RECEPCAO', NOW() - INTERVAL 90 MINUTE, NOW() - INTERVAL 87 MINUTE, NULL),
  (5, 1, 'RECEPCAO', NOW() - INTERVAL 5 MINUTE, NOW() - INTERVAL 2 MINUTE, NULL),
  (6, 1, 'RECEPCAO', NOW() - INTERVAL 30 MINUTE, NOW() - INTERVAL 27 MINUTE, NULL),
  (1, 2, 'TRIAGEM', NOW() - INTERVAL 175 MINUTE, NOW() - INTERVAL 170 MINUTE, 'Paciente consciente, febril, sem sinais de gravidade'),
  (2, 2, 'TRIAGEM', NOW() - INTERVAL 45 MINUTE, NOW() - INTERVAL 40 MINUTE, 'Desidratação leve, mucosas secas'),
  (3, 2, 'TRIAGEM', NOW() - INTERVAL 18 MINUTE, NOW() - INTERVAL 15 MINUTE, 'Dor torácica com sudorese; prioridade para avaliação médica'),
  (4, 2, 'TRIAGEM', NOW() - INTERVAL 85 MINUTE, NOW() - INTERVAL 80 MINUTE, 'Tosse produtiva há 3 dias, sem desconforto respiratório'),
  (1, 3, 'ATENDIMENTO_MEDICO', NOW() - INTERVAL 100 MINUTE, NOW() - INTERVAL 80 MINUTE, 'Quadro viral. Repouso e hidratação. Alta.');

INSERT INTO prescricao (id_atendimento, medicamento, dosagem, via_administracao, frequencia, dt_prescricao, dt_administracao) VALUES
  (1, 'Dipirona 500 mg/ml injetável', '2 ml', 'INTRAVENOSA', 'Dose única', NOW() - INTERVAL 95 MINUTE, NOW() - INTERVAL 90 MINUTE),
  (1, 'Paracetamol 750 mg', '1 comprimido', 'ORAL', '6/6h por 3 dias se febre', NOW() - INTERVAL 85 MINUTE, NULL);
