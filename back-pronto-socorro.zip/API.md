# API do Pronto Socorro

Todas as rotas respondem JSON. Erros vêm como `{ "erro": "mensagem em português" }`.
Sessão por cookie `ps_sessao` (HttpOnly, 8 h). Perfis: `RECEPCIONISTA`, `ENFERMEIRO`, `MEDICO`.
"Logado" = qualquer perfil.

| Método e rota | Perfil | O que faz |
|---|---|---|
| `POST /api/login` | público | Entra (`login`, `senha`). Bloqueia após 5 erros em 15 min |
| `POST /api/logout` | público | Sai |
| `GET /api/me` | público | Usuário da sessão ou `null` |
| `GET /api/resumo` | público | Contagem por status (tela inicial) |
| `GET /api/pacientes` | Recepção | Lista; filtros `?cpf=` ou `?nome=` |
| `GET /api/pacientes/:id` | Recepção | Paciente completo |
| `POST /api/pacientes` | Recepção | Cadastra (valida CPF, datas, tamanhos) |
| `PUT /api/pacientes/:id` | Recepção | Altera |
| `GET /api/atendimentos` | Recepção, Enfermagem | Lista; filtros `?status=`, `?numero=AT0001`, `?hoje=1` |
| `GET /api/atendimentos/:id` | Logado | Paciente + triagem + prontuário |
| `POST /api/atendimentos` | Recepção | Abre atendimento (`id_paciente`, `observacao`); gera `AT0001`... |
| `PUT /api/atendimentos/:id` | Recepção | Altera observação, só antes da alta/cancelamento |
| `POST /api/atendimentos/:id/cancelar` | Recepção | Cancela com `motivo`, só antes da alta |
| `POST /api/triagem` | Enfermagem | Grava triagem; status vai a `AGUARDANDO_MEDICO` |
| `GET /api/triagem/:idAtendimento` | Enfermagem, Médico | Lê a triagem |
| `POST /api/triagem/:idAtendimento/reclassificar` | Enfermagem | Muda a cor enquanto aguarda o médico |
| `GET /api/painel` | Logado | Fila de Manchester (prioridade, depois ordem na fila) |
| `GET /api/painel/atrasados` | Médico | Quem passou do tempo máximo da cor |
| `POST /api/atendimentos/:id/iniciar` | Médico | Chama o paciente e abre o prontuário |
| `POST /api/atendimentos/:id/finalizar` | Médico | Alta (`anotacao`, `diagnostico` opcional) |
| `GET /api/prescricoes/:idAtendimento` | Médico | Medicações do atendimento |
| `POST /api/prescricoes` | Médico | Lança medicação (`id_atendimento`, `medicamento`, `dosagem`, `via_administracao`, `frequencia`) |
| `POST /api/prescricoes/:id/administrar` | Médico | Marca como administrada |
| `DELETE /api/prescricoes/:id` | Médico | Remove, se ainda não administrada |
| `GET /api/prontuarios` | Logado | Lista de prontuários |
| `GET /api/pacientes/:id/historico` | Logado | Todas as visitas do paciente |
| `GET /api/historico?cpf=` | Logado | Histórico pelo CPF |
| `GET /api/pacientes/:id/medicacoes` | Logado | Medicações de todas as visitas |
| `GET /api/relatorios` | Logado | Totais por status, cor, médico e tempo médio |

## Regras garantidas pelo servidor

- Fluxo: `AGUARDANDO_TRIAGEM` → `AGUARDANDO_MEDICO` → `EM_ATENDIMENTO` → `FINALIZADO` (ou `CANCELADO`).
- Etapa fora de ordem retorna 409 com a explicação (ex.: médico chamando quem não foi triado).
- Após `FINALIZADO` não é possível alterar, cancelar, prescrever nem finalizar de novo.
- Um paciente não pode ter dois atendimentos abertos ao mesmo tempo.
- `id_recepcionista`, `id_enfermeiro` e `id_medico` vêm sempre do usuário logado, nunca do corpo da requisição.
- Cada ação que muda mais de uma tabela roda em transação, com a linha do atendimento travada.
- Profissional desativado perde o acesso na hora (a sessão é conferida no banco a cada requisição).

## Administração de profissionais (linha de comando)

Não há perfil de administrador, então isso não está na API:

```
node cadastrar-profissional.js listar
node cadastrar-profissional.js recepcionista "Nome" 52998224725 login senha
node cadastrar-profissional.js enfermeiro "Nome" 52998224725 login senha "COREN-SP 111"
node cadastrar-profissional.js medico "Nome" 52998224725 login senha "CRM-SP 222" "Clínica Médica"
node cadastrar-profissional.js ativo login nao
```
