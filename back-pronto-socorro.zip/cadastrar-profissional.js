// Administração de profissionais pela linha de comando.
// Não existe perfil de administrador no sistema, então isso não fica exposto na API.
//
//   node cadastrar-profissional.js listar
//   node cadastrar-profissional.js recepcionista "<nome>" <cpf> <login> <senha>
//   node cadastrar-profissional.js enfermeiro    "<nome>" <cpf> <login> <senha> <coren>
//   node cadastrar-profissional.js medico        "<nome>" <cpf> <login> <senha> <crm> [especialidade]
//   node cadastrar-profissional.js ativo <login> <sim|nao>
const pool = require('./db');
const { hashSenha } = require('./auth');
const { cpfValido } = require('./validacao');

const uso = () => {
  console.log('Uso:');
  console.log('  node cadastrar-profissional.js listar');
  console.log('  node cadastrar-profissional.js recepcionista "<nome>" <cpf> <login> <senha>');
  console.log('  node cadastrar-profissional.js enfermeiro    "<nome>" <cpf> <login> <senha> <coren>');
  console.log('  node cadastrar-profissional.js medico        "<nome>" <cpf> <login> <senha> <crm> [especialidade]');
  console.log('  node cadastrar-profissional.js ativo <login> <sim|nao>');
  process.exit(1);
};

async function cadastrar(funcao, nome, cpfBruto, login, senha, registro, especialidade) {
  const cpf = String(cpfBruto || '').replace(/\D/g, '');
  if (!nome || !login || !senha) uso();
  if (!cpfValido(cpf)) throw new Error('CPF inválido.');
  if (senha.length < 4) throw new Error('Use uma senha com pelo menos 4 caracteres.');
  if (funcao !== 'RECEPCIONISTA' && !registro) throw new Error(funcao === 'MEDICO' ? 'Informe o CRM.' : 'Informe o COREN.');

  const c = await pool.getConnection();
  try {
    await c.beginTransaction();
    const [r] = await c.query(
      'INSERT INTO profissional (nome, cpf, funcao, login, senha_hash) VALUES (?, ?, ?, ?, ?)',
      [nome, cpf, funcao, login, hashSenha(senha)]
    );
    if (funcao === 'ENFERMEIRO') {
      await c.query('INSERT INTO enfermeiro (id_profissional, coren) VALUES (?, ?)', [r.insertId, registro]);
    } else if (funcao === 'MEDICO') {
      await c.query('INSERT INTO medico (id_profissional, crm, especialidade) VALUES (?, ?, ?)', [r.insertId, registro, especialidade || null]);
    }
    await c.commit();
    console.log(`${funcao} cadastrado: ${nome} (login ${login}).`);
  } catch (e) {
    await c.rollback().catch(() => {});
    throw e;
  } finally {
    c.release();
  }
}

(async () => {
  const [acao, ...a] = process.argv.slice(2);
  if (!acao) uso();

  if (acao === 'listar') {
    const [l] = await pool.query(
      `SELECT pf.id_profissional, pf.nome, pf.funcao, pf.login, pf.ativo, m.crm, m.especialidade, e.coren
         FROM profissional pf
         LEFT JOIN medico m     ON m.id_profissional = pf.id_profissional
         LEFT JOIN enfermeiro e ON e.id_profissional = pf.id_profissional
        ORDER BY pf.funcao, pf.nome`
    );
    console.table(l);
  } else if (acao === 'recepcionista') {
    await cadastrar('RECEPCIONISTA', a[0], a[1], a[2], a[3]);
  } else if (acao === 'enfermeiro') {
    await cadastrar('ENFERMEIRO', a[0], a[1], a[2], a[3], a[4]);
  } else if (acao === 'medico') {
    await cadastrar('MEDICO', a[0], a[1], a[2], a[3], a[4], a[5]);
  } else if (acao === 'ativo') {
    if (!a[0] || !['sim', 'nao'].includes(a[1])) uso();
    const [r] = await pool.query('UPDATE profissional SET ativo = ? WHERE login = ?', [a[1] === 'sim', a[0]]);
    console.log(r.affectedRows ? `Login ${a[0]} ${a[1] === 'sim' ? 'reativado' : 'desativado'}.` : 'Login não encontrado: ' + a[0]);
  } else {
    uso();
  }
  await pool.end();
})().catch(e => {
  console.error('Erro:', e.sqlMessage || e.message);
  process.exit(1);
});
