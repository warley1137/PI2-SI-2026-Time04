require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const pool = require('./db');
const { conferirSenha } = require('./auth');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const CORES = ['Vermelho', 'Laranja', 'Amarelo', 'Verde', 'Azul'];

/* ---------- funções auxiliares ---------- */

// transforma texto vazio em null (para gravar NULL no banco)
function vazioParaNull(valor) {
  if (valor === undefined || valor === null) return null;
  const texto = String(valor).trim();
  return texto === '' ? null : texto;
}

function erroServidor(res, e) {
  console.log(e);
  res.status(500).json({ erro: 'Erro no servidor.' });
}

// busca o atendimento pelo id (retorna undefined se não existir)
async function buscarAtendimento(id) {
  const [linhas] = await pool.query('SELECT id_atendimento, status FROM atendimento WHERE id_atendimento = ?', [id]);
  return linhas[0];
}

/* ---------- login e sessão (cookie assinado) ---------- */

const SEGREDO = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

function criarToken(dados) {
  const corpo = Buffer.from(JSON.stringify(dados)).toString('base64url');
  const assinatura = crypto.createHmac('sha256', SEGREDO).update(corpo).digest('base64url');
  return corpo + '.' + assinatura;
}

function lerToken(token) {
  if (!token) return null;
  const [corpo, assinatura] = token.split('.');
  if (!corpo || !assinatura) return null;
  const esperada = crypto.createHmac('sha256', SEGREDO).update(corpo).digest('base64url');
  if (assinatura !== esperada) return null;
  const dados = JSON.parse(Buffer.from(corpo, 'base64url').toString());
  if (dados.exp < Date.now()) return null;
  return dados;
}

function usuarioDaRequisicao(req) {
  const cookies = (req.headers.cookie || '').split(';').map(c => c.trim());
  const achado = cookies.find(c => c.startsWith('ps_sessao='));
  if (!achado) return null;
  try {
    return lerToken(achado.slice('ps_sessao='.length));
  } catch (e) {
    return null;
  }
}

// uso: auth() = qualquer usuário logado; auth('MEDICO') = só médico
function auth(...perfis) {
  return (req, res, next) => {
    const usuario = usuarioDaRequisicao(req);
    if (!usuario) return res.status(401).json({ erro: 'Faça login para continuar.' });
    if (perfis.length > 0 && !perfis.includes(usuario.funcao)) {
      return res.status(403).json({ erro: 'Seu perfil não tem acesso a esta função.' });
    }
    req.usuario = usuario;
    next();
  };
}

app.post('/api/login', async (req, res) => {
  try {
    const { login, senha } = req.body;
    if (!login || !senha) return res.status(400).json({ erro: 'Informe login e senha.' });

    const [linhas] = await pool.query(
      'SELECT id_profissional, nome, funcao, senha_hash FROM profissional WHERE login = ? AND ativo = TRUE',
      [login]
    );
    const u = linhas[0];
    if (!u || !conferirSenha(senha, u.senha_hash)) {
      return res.status(401).json({ erro: 'Login ou senha incorretos.' });
    }

    const token = criarToken({ id: u.id_profissional, nome: u.nome, funcao: u.funcao, exp: Date.now() + 8 * 60 * 60 * 1000 });
    res.setHeader('Set-Cookie', `ps_sessao=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`);
    res.json({ nome: u.nome, funcao: u.funcao });
  } catch (e) { erroServidor(res, e); }
});

app.post('/api/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'ps_sessao=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const u = usuarioDaRequisicao(req);
  res.json(u ? { nome: u.nome, funcao: u.funcao } : null);
});

// números da tela inicial (não precisa de login)
app.get('/api/resumo', async (req, res) => {
  try {
    const [linhas] = await pool.query('SELECT status, COUNT(*) AS n FROM atendimento GROUP BY status');
    const por = {};
    linhas.forEach(l => { por[l.status] = l.n; });
    res.json({ por });
  } catch (e) { erroServidor(res, e); }
});

/* ---------- recepção: pacientes ---------- */

app.get('/api/pacientes', auth('RECEPCIONISTA'), async (req, res) => {
  try {
    const [linhas] = await pool.query(
      'SELECT id_paciente, nome, cpf, data_nascimento, telefone FROM paciente ORDER BY nome'
    );
    res.json(linhas);
  } catch (e) { erroServidor(res, e); }
});

app.post('/api/pacientes', auth('RECEPCIONISTA'), async (req, res) => {
  try {
    const b = req.body;
    const nome = vazioParaNull(b.nome);
    const dataNascimento = vazioParaNull(b.data_nascimento);
    if (!nome || !dataNascimento) {
      return res.status(400).json({ erro: 'Preencha o nome e a data de nascimento.' });
    }

    // CPF: guarda só os números (11 dígitos)
    let cpf = vazioParaNull(b.cpf);
    if (cpf) {
      cpf = cpf.replace(/\D/g, '');
      if (cpf.length !== 11) return res.status(400).json({ erro: 'O CPF deve ter 11 números.' });
    }

    const [r] = await pool.query(
      `INSERT INTO paciente (nome, cpf, rg, data_nascimento, sexo, nome_mae, nome_pai, telefone,
                             cep, logradouro, numero, complemento, bairro, cidade, uf)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [nome, cpf, vazioParaNull(b.rg), dataNascimento, vazioParaNull(b.sexo), vazioParaNull(b.nome_mae),
       vazioParaNull(b.nome_pai), vazioParaNull(b.telefone), vazioParaNull(b.cep), vazioParaNull(b.logradouro),
       vazioParaNull(b.numero), vazioParaNull(b.complemento), vazioParaNull(b.bairro), vazioParaNull(b.cidade),
       vazioParaNull(b.uf)]
    );
    res.status(201).json({ id_paciente: r.insertId });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ erro: 'Já existe um paciente com este CPF.' });
    erroServidor(res, e);
  }
});

/* ---------- recepção: atendimentos ---------- */

app.get('/api/atendimentos', auth('RECEPCIONISTA', 'ENFERMEIRO'), async (req, res) => {
  try {
    let sql = `SELECT a.id_atendimento, a.numero_atendimento, a.status, a.dt_chegada, p.nome AS paciente
                 FROM atendimento a
                 JOIN paciente p ON p.id_paciente = a.id_paciente`;
    const params = [];
    if (req.query.status) {
      sql += ' WHERE a.status = ?';
      params.push(req.query.status);
    }
    sql += ' ORDER BY a.dt_chegada DESC LIMIT 200';
    const [linhas] = await pool.query(sql, params);
    res.json(linhas);
  } catch (e) { erroServidor(res, e); }
});

app.post('/api/atendimentos', auth('RECEPCIONISTA'), async (req, res) => {
  try {
    const idPaciente = Number(req.body.id_paciente);
    if (!idPaciente) return res.status(400).json({ erro: 'Selecione um paciente.' });

    const [pacientes] = await pool.query('SELECT id_paciente FROM paciente WHERE id_paciente = ?', [idPaciente]);
    if (pacientes.length === 0) return res.status(404).json({ erro: 'Paciente não encontrado.' });

    // o paciente não pode ter outro atendimento aberto
    const [abertos] = await pool.query(
      "SELECT numero_atendimento FROM atendimento WHERE id_paciente = ? AND status NOT IN ('FINALIZADO', 'CANCELADO')",
      [idPaciente]
    );
    if (abertos.length > 0) {
      return res.status(409).json({ erro: 'Este paciente já tem o atendimento ' + abertos[0].numero_atendimento + ' em aberto.' });
    }

    const [r] = await pool.query(
      'INSERT INTO atendimento (id_paciente, id_recepcionista, observacao) VALUES (?, ?, ?)',
      [idPaciente, req.usuario.id, vazioParaNull(req.body.observacao)]
    );

    // número do atendimento: AT0001, AT0002...
    const numero = 'AT' + String(r.insertId).padStart(4, '0');
    await pool.query('UPDATE atendimento SET numero_atendimento = ? WHERE id_atendimento = ?', [numero, r.insertId]);

    res.status(201).json({ id_atendimento: r.insertId, numero_atendimento: numero });
  } catch (e) { erroServidor(res, e); }
});

app.post('/api/atendimentos/:id/cancelar', auth('RECEPCIONISTA'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    const motivo = vazioParaNull(req.body.motivo);
    if (!motivo) return res.status(400).json({ erro: 'Informe o motivo do cancelamento.' });

    const atendimento = await buscarAtendimento(id);
    if (!atendimento) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
    if (atendimento.status === 'FINALIZADO') return res.status(409).json({ erro: 'Atendimento finalizado não pode ser cancelado.' });
    if (atendimento.status === 'CANCELADO') return res.status(409).json({ erro: 'Este atendimento já está cancelado.' });

    await pool.query(
      "UPDATE atendimento SET status = 'CANCELADO', dt_cancelamento = NOW(), motivo_cancelamento = ? WHERE id_atendimento = ?",
      [motivo, id]
    );
    // se o prontuário já tinha sido aberto, encerra ele também
    await pool.query('UPDATE prontuario SET dt_fim = NOW() WHERE id_atendimento = ? AND dt_fim IS NULL', [id]);
    res.json({ ok: true });
  } catch (e) { erroServidor(res, e); }
});

/* ---------- enfermagem: triagem ---------- */

app.post('/api/triagem', auth('ENFERMEIRO'), async (req, res) => {
  try {
    const b = req.body;
    const idAtendimento = Number(b.id_atendimento);
    const queixas = vazioParaNull(b.queixas);

    if (!idAtendimento) return res.status(400).json({ erro: 'Selecione um atendimento.' });
    if (!b.pressao_sistolica || !b.pressao_diastolica || !b.temperatura || !b.frequencia_cardiaca || !queixas) {
      return res.status(400).json({ erro: 'Preencha todos os campos da triagem.' });
    }
    if (!CORES.includes(b.classificacao)) {
      return res.status(400).json({ erro: 'Escolha a classificação de risco.' });
    }

    const atendimento = await buscarAtendimento(idAtendimento);
    if (!atendimento) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
    if (atendimento.status !== 'AGUARDANDO_TRIAGEM') {
      return res.status(409).json({ erro: 'Este atendimento não está aguardando triagem.' });
    }

    await pool.query(
      `INSERT INTO triagem (id_atendimento, id_enfermeiro, pressao_sistolica, pressao_diastolica,
                            temperatura, frequencia_cardiaca, queixas, classificacao)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [idAtendimento, req.usuario.id, b.pressao_sistolica, b.pressao_diastolica,
       String(b.temperatura).replace(',', '.'), b.frequencia_cardiaca, queixas, b.classificacao]
    );
    await pool.query("UPDATE atendimento SET status = 'AGUARDANDO_MEDICO' WHERE id_atendimento = ?", [idAtendimento]);
    res.status(201).json({ ok: true });
  } catch (e) { erroServidor(res, e); }
});

/* ---------- painel (todos os perfis) ---------- */

app.get('/api/painel', auth(), async (req, res) => {
  try {
    const [linhas] = await pool.query('SELECT * FROM vw_painel_atendimento ORDER BY prioridade, dt_triagem');
    res.json(linhas);
  } catch (e) { erroServidor(res, e); }
});

/* ---------- médico ---------- */

// "Chamar paciente": abre o prontuário
app.post('/api/atendimentos/:id/iniciar', auth('MEDICO'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    const atendimento = await buscarAtendimento(id);
    if (!atendimento) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
    if (atendimento.status !== 'AGUARDANDO_MEDICO') {
      return res.status(409).json({ erro: 'O paciente precisa estar aguardando o médico (depois da triagem).' });
    }

    await pool.query("UPDATE atendimento SET status = 'EM_ATENDIMENTO' WHERE id_atendimento = ?", [id]);
    const [r] = await pool.query('INSERT INTO prontuario (id_atendimento, id_medico) VALUES (?, ?)', [id, req.usuario.id]);
    res.json({ id_prontuario: r.insertId });
  } catch (e) { erroServidor(res, e); }
});

app.post('/api/atendimentos/:id/finalizar', auth('MEDICO'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    const atendimento = await buscarAtendimento(id);
    if (!atendimento) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
    if (atendimento.status !== 'EM_ATENDIMENTO') {
      return res.status(409).json({ erro: 'Só dá para finalizar um atendimento que está em andamento.' });
    }

    await pool.query("UPDATE atendimento SET status = 'FINALIZADO' WHERE id_atendimento = ?", [id]);
    await pool.query('UPDATE prontuario SET dt_fim = NOW(), observacao = ? WHERE id_atendimento = ?',
      [vazioParaNull(req.body.anotacao), id]);
    res.json({ ok: true });
  } catch (e) { erroServidor(res, e); }
});

app.get('/api/prescricoes/:idAtendimento', auth('MEDICO'), async (req, res) => {
  try {
    const [linhas] = await pool.query(
      `SELECT pc.id_prescricao, pc.medicamento, pc.dosagem, pc.via_administracao, pc.frequencia
         FROM prescricao pc
         JOIN prontuario pr ON pr.id_prontuario = pc.id_prontuario
        WHERE pr.id_atendimento = ?
        ORDER BY pc.id_prescricao`,
      [Number(req.params.idAtendimento)]
    );
    res.json(linhas);
  } catch (e) { erroServidor(res, e); }
});

app.post('/api/prescricoes', auth('MEDICO'), async (req, res) => {
  try {
    const b = req.body;
    const idAtendimento = Number(b.id_atendimento);
    const medicamento = vazioParaNull(b.medicamento);
    const dosagem = vazioParaNull(b.dosagem);
    const via = vazioParaNull(b.via_administracao);
    if (!idAtendimento || !medicamento || !dosagem || !via) {
      return res.status(400).json({ erro: 'Preencha medicamento, dosagem e via de administração.' });
    }

    const atendimento = await buscarAtendimento(idAtendimento);
    if (!atendimento) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
    if (atendimento.status !== 'EM_ATENDIMENTO') {
      return res.status(409).json({ erro: 'Só dá para lançar medicação em atendimento em andamento.' });
    }

    const [prontuarios] = await pool.query('SELECT id_prontuario FROM prontuario WHERE id_atendimento = ?', [idAtendimento]);
    if (prontuarios.length === 0) return res.status(409).json({ erro: 'O prontuário ainda não foi aberto.' });

    const [r] = await pool.query(
      'INSERT INTO prescricao (id_prontuario, medicamento, dosagem, via_administracao, frequencia) VALUES (?, ?, ?, ?, ?)',
      [prontuarios[0].id_prontuario, medicamento, dosagem, via, vazioParaNull(b.frequencia)]
    );
    res.status(201).json({ id_prescricao: r.insertId });
  } catch (e) { erroServidor(res, e); }
});

/* ---------- prontuário (todos os perfis) ---------- */

app.get('/api/prontuarios', auth(), async (req, res) => {
  try {
    const [linhas] = await pool.query(
      `SELECT a.id_atendimento, a.numero_atendimento, a.status, a.dt_chegada, p.nome AS paciente,
              t.classificacao, t.queixas, pr.observacao AS anotacao, pr.dt_fim,
              (SELECT COUNT(*) FROM prescricao x WHERE x.id_prontuario = pr.id_prontuario) AS prescricoes
         FROM atendimento a
         JOIN paciente p         ON p.id_paciente     = a.id_paciente
         LEFT JOIN triagem t     ON t.id_atendimento  = a.id_atendimento
         LEFT JOIN prontuario pr ON pr.id_atendimento = a.id_atendimento
        ORDER BY a.dt_chegada DESC LIMIT 200`
    );
    res.json(linhas);
  } catch (e) { erroServidor(res, e); }
});

/* ---------- iniciar o servidor ---------- */

const porta = process.env.PORT || 3000;
pool.query('SELECT 1')
  .then(() => {
    console.log('Banco conectado.');
    app.listen(porta, () => console.log('Abra http://localhost:' + porta));
  })
  .catch(e => {
    console.log('Não foi possível conectar ao banco:', e.code || e.message);
    console.log('Confira as credenciais no db.js e se o MySQL está ligado.');
    process.exit(1);
  });
